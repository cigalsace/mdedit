
<!-- Begin @md_datestamp.md -->

# Date de la fiche

## Définition
Date de création ou de dernière mise à jour de la fiche.

## Recommandations
Cette information est généralement générée automatiquement par l’application lors de la création/modification de la fiche.

## Exemples
Date de la fiche : « 02/10/2008 »

<!-- End @md_datestamp.md -->

