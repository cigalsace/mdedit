
<!-- Begin @data_dq_inspireconformities_dates.md -->

# Conformité de la donnée aux règles d’interopérabilité Inspire
## Date de création / modification / publication de la spécification
### Définition
Cette information indique la date de modification, publication ou révision de la spécification renseignée.
### Recommandations
Se rapporter à la spécification pour en connaître la date de création, publication ou révision (cf. tableau du paragraphe 7.2.1.1).
### Exemples
Date de publication : « 0#08 »

<!-- End @data_dq_inspireconformities_dates.md -->

