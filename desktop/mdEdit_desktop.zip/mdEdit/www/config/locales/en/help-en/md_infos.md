
<!-- Begin @md_infos.md -->

# Information sur les métadonnées

<!-- End @md_infos.md -->
