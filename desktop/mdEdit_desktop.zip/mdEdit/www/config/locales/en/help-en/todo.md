
<!-- Begin @todo.md -->

7.# Degré de conformité
7.#1. Définition
Cette information précise le résultat du test de conformité.
La liste des valeurs possible est la suivante : « Conforme », « Non conforme » et « Non évalué ».
7.#2. Recommandations
Si cette information n’est pas renseignée, le degré de conformité est considéré comme « Non évalué ».
La valeur par défaut est « Non évalué ».
7.#3. Exemples
Degré de conformité : « Non évalué »

<!-- End @todo.md -->