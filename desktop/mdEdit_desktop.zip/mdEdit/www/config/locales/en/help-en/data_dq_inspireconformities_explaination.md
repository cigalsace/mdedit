
<!-- Begin @data_dq_inspireconformities_explaination.md -->

# Conformité de la donnée aux règles d’interopérabilité Inspire
## Explication du test réalisé
### Définition
Cette information permet de renseigner l’utilisateur sur la manière dont le degré de conformité a été évalué.
### Recommandations
Il ne s’agit pas d’indiquer le degré de conformité (cf. paragraphe 7.#, mais la façon dont celui-ci a été évalué et les éventuels problèmes rencontrés.
### Exemples
Résultat du test : « … »

<!-- End @data_dq_inspireconformities_explaination.md -->

