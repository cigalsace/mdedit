/**
 * [module description]
 * @param  {[type]} 'modalGetXml' [description]
 * @param  {[type]} []            [description]
 * @return {[type]}               [description]
 */
angular.module('modalGetXml', []);
