/**
 * [module description]
 * @param  {[type]} 'modalSetXml' [description]
 * @param  {[type]} []            [description]
 * @return {[type]}               [description]
 */
angular.module('modalSetXml', []);
