// Service
/**
 * [module description]
 * @param  {[type]} 'modalSetXml' [description]
 * @return {[type]}               [description]
 */
angular.module('modalSetXml')
    .factory('modalSetXmlSrv', modalSetXmlSrv);

modalSetXmlSrv.$inject = ['$http'];

function modalSetXmlSrv($http) {

}
