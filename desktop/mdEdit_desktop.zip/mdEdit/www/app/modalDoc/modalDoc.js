/**
 * [module description]
 * @param  {[type]} 'modalDoc' [description]
 * @param  {[type]} ['config'  [description]
 * @param  {[type]} 'locales'] [description]
 * @return {[type]}            [description]
 */
angular.module('modalDoc', ['config', 'locales']);
