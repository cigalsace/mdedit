
<!-- Begin @data_dq_inspireconformities_pass.md -->

# Conformité de la donnée aux règles d’interopérabilité Inspire
## Degré de conformité
### Définition
Cette information précise le résultat du test de conformité.
La liste des valeurs possible est la suivante : « Conforme », « Non conforme » et « Non évalué ».
### Recommandations
Si cette information n’est pas renseignée, le degré de conformité est considéré comme « Non évalué ».
La valeur par défaut est « Non évalué ».
### Exemples
Degré de conformité : « Non évalué »

<!-- End @data_dq_inspireconformities_pass.md -->

