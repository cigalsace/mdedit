
<!-- Begin @data_dq_inspireconformities_specification.md -->

# Conformité de la donnée aux règles d’interopérabilité Inspire
7.#Nom de la spécification
7.#. Définition
Cette information indique le nom du standard, de la norme ou autre spécification pour lequel le degré de conformité de la donnée a été évalué.
7.#. Recommandations
La conformité aux règles d’interopérabilité Inspire ne doit pas être renseigné à ce niveau (cf. paragraphe 7.2.1).
7.#. Exemples
Nom de la spécification : « Géostandard de la COVADIS : Aménagement Numérique des Territoires - Infrastructures de communications électroniques »

<!-- End @data_dq_inspireconformities_specification.md -->

