# Directive pour la consultation

Le code pour la génération de la vue de consultation des fiches n'a pas encore été converti en directives.
