// Service
/**
 * [module description]
 * @param  {[type]} 'modalGetXml' [description]
 * @return {[type]}               [description]
 */
angular.module('modalGetXml')
    .factory('modalGetXmlSrv', modalGetXmlSrv);

modalGetXmlSrv.$inject = ['$http'];

function modalGetXmlSrv($http) {


}
